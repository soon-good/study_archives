package com.study.qdsl;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QdslApplicationTests {

	@Test
	void contextLoads() {
	}

}
